
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

void main() {
  runApp(MyApp());
}

class ThemeSettings {
  final Color primaryColor;
  final Color backgroundColor;
  final Color textColor;

  ThemeSettings(this.primaryColor, this.backgroundColor, this.textColor);
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeSettings currentTheme = ThemeSettings(Colors.blue, Colors.white, Colors.black);

  void updateTheme(ThemeSettings newTheme) {
    setState(() {
      currentTheme = newTheme;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Custom Chat App',
      theme: ThemeData(
        primaryColor: currentTheme.primaryColor,
        scaffoldBackgroundColor: currentTheme.backgroundColor,
        textTheme: TextTheme(bodyText2: TextStyle(color: currentTheme.textColor)),
      ),
      home: ChatPage(onThemeChange: updateTheme),
    );
  }
}

class ChatPage extends StatefulWidget {
  final Function(ThemeSettings) onThemeChange;

  ChatPage({required this.onThemeChange});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _controller = TextEditingController();
  List<String> messages = [];
  bool emojiVisible = false;

  void sendMessage() {
    if (_controller.text.trim().isEmpty) return;
    setState(() {
      messages.add(_controller.text.trim());
      _controller.clear();
    });
  }

  void onEmojiSelected(String emoji) {
    _controller.text += emoji;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Messagerie"),
        actions: [
          IconButton(
            icon: Icon(Icons.color_lens),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => ThemePage(onThemeChange: widget.onThemeChange),
              ));
            },
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (_, i) => ListTile(title: Text(messages[i])),
            ),
          ),
          if (emojiVisible)
            SizedBox(
              height: 250,
              child: EmojiPicker(
                onEmojiSelected: (category, emoji) => onEmojiSelected(emoji.emoji),
              ),
            ),
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.emoji_emotions),
                onPressed: () => setState(() => emojiVisible = !emojiVisible),
              ),
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration: InputDecoration(hintText: "Écrire un message..."),
                ),
              ),
              IconButton(icon: Icon(Icons.send), onPressed: sendMessage),
            ],
          ),
        ],
      ),
    );
  }
}

class ThemePage extends StatelessWidget {
  final Function(ThemeSettings) onThemeChange;

  ThemePage({required this.onThemeChange});

  final List<ThemeSettings> themes = [
    ThemeSettings(Colors.blue, Colors.white, Colors.black),
    ThemeSettings(Colors.black, Colors.grey[900]!, Colors.white),
    ThemeSettings(Colors.purple, Colors.pink[50]!, Colors.purple),
    ThemeSettings(Colors.teal, Colors.teal[50]!, Colors.teal[900]!),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Thèmes")),
      body: ListView.builder(
        itemCount: themes.length,
        itemBuilder: (_, i) {
          return ListTile(
            title: Text("Thème ${i + 1}"),
            leading: CircleAvatar(backgroundColor: themes[i].primaryColor),
            onTap: () {
              onThemeChange(themes[i]);
              Navigator.pop(context);
            },
          );
        },
      ),
    );
  }
}
