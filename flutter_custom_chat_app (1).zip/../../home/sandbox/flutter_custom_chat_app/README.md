# Flutter Custom Chat App

A customizable messaging app with themes and emojis.